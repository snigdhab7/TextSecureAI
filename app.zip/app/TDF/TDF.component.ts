import { Component, OnInit } from '@angular/core';
import {User} from './users';
@Component({
    selector: 'app-TDF',
    templateUrl: `./TDF.component.html`,
    styles:[]
})

export class TDFComponent implements OnInit{
    userModel=new User('Neel Barve','neel@gmail.com',987621543,'','morning',true);
    levels=['1Q','2Q','3Q','4Q','5Q'];
    constructor(){}
    ngOnInit(){}
    onSubmit()
    {
        console.log(this.userModel);
    }
}