export class User
{
    constructor(
        public fullName:string,
        public emailAddress:string,
        public mobileNo:number,
        public profLevel:string,
        public timePreference:string,
        public notification:boolean
    ){}
}