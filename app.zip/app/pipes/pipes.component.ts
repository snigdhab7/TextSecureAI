import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pipes',
  templateUrl: './pipes.component.html',
  styleUrls: []
})
export class PipesComponent implements OnInit {
    ngOnInit(): void {}
    pageTitle:string="formatting using pipes in angular";
    users:any[]=[
        {id:101,name:'rahul',city:'DELHI',salary:2,dob:new Date("05/10/1989")},
        {id:102,name:'rohit',city:'CHENNAI',salary:450,dob:new Date("12/11/1987")},
        {id:103,name:'mohit',city:'PUNE',salary:5000,dob:new Date("09/22/1988")},
        {id:104,name:'rishi',city:'BANGALORE',salary:70000.888888,dob:new Date("01/10/1990")},
    ];
}