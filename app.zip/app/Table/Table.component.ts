import {Component,OnInit} from '@angular/core';
@Component({
selector: 'app-table',
template: `
<pre>
<table>
<tr>
<td> ID:</td>
<td> <input type="number" [(ngModel)]="id" /> </td>
</tr>
<tr>
<td> Name:</td> 
<td> <input type="text" [(ngModel)]="name" /> </td>
</tr>
<tr>
<td> Salary:</td> 
<td> <input type="number" [(ngModel)]="salary"/> </td>
<tr> 
<td> Department: </td>
<td><input type="text" [(ngModel)]="dept"/></td>
</table> 
<input type="button" (click)="Click()" value="Add Employee"/>
</pre>
<table padding="3" border="2" >
<tr>
<th> ID </th>
<th> Name </th>
<th> Salary </th>
<th> DEpartment </th>
<th colspan="2"> Action </th>
</tr>
<tr *ngFor="let emp of empdata">
<td> {{emp.id}} </td>
<td> {{emp.name}} </td>
<td> {{emp.salary}} </td>
<td> {{emp.dept}} </td>
<td> <input type="button" value="Update" (click)="update(emp)"/> </td>
<td> <input type="button" value="Delete" (click)="delete(emp)"/> </td>
</tr>
</table>
<h4> Update Details: </h4>
<table padding="3" border="2" >
<tr>
<th> ID </th>
<th> Name </th>
<th> Salary </th>
<th> DEpartment </th>
<th> Action </th>
</tr>
<tr>
<td> <input type="number" [(ngModel)]="id1"/> </td>
<td> <input type="text" [(ngModel)]="name1"/> </td>
<td> <input type="number" [(ngModel)]="salary1"/> </td>
<td> <input type="text" [(ngModel)]="dept1"/> </td>
<td> <input type="button" (click)="updated()" value="Update"/> </td>
</tr>
</table>
`,
styles:[]

})
export class TableComponent implements OnInit{
    empdata=[{id:121,name:"Rohan",salary:200000,dept:"Finance"},{id:122,name:"Akash",salary:120000,dept:"Finance"}];
    id;
    name="";
    salary;
    dept="";
    constructor(){}
    ngOnInit(){}
    Click()
    {
        let obj={id:this.id,name:this.name,salary:this.salary,dept:this.dept};
        this.empdata.push(obj);
    }
    id1;
    name1="";
    salary1;
    index:number;
    dept1="";
update(em)
{ this.id1=em.id;
    this.name1=em.name;
    this.salary1=em.salary;
    this.dept1=em.dept;
    this.index=this.empdata.indexOf(em);
} 
updated()
{
    this.empdata.splice(this.index,1,{id:this.id1,name:this.name1,salary:this.salary1,dept:this.dept1});
    alert("updated");
}
delete(em)
{
    this.empdata.splice(this.empdata.indexOf(em),1);
    alert("deleted");
}
}