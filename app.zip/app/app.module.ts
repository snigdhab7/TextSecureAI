import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BindingComponent } from './binding/binding.component';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import { ChildComponent } from './child/child.component';
import { PipesComponent } from './pipes/pipes.component';
import { AgePipe } from './custmpipe/age.pipe';
import { MDFComponent } from './MDF/MDF.component';
import { TDFComponent } from './TDF/TDF.component';
import { TDFSelfComponent } from './TDFself/TDFself.component';
import { MDFSelfComponent } from './MDFself/MDFself.component';
import { TableComponent } from './Table/Table.component';
import { SortComponent } from './sort/sort.component';

@NgModule({
  declarations: [
    AppComponent,
    BindingComponent,
    ChildComponent,
    PipesComponent,
    AgePipe,
    MDFComponent,
    TDFComponent,
    TDFSelfComponent,
    MDFSelfComponent,
    TableComponent,
    SortComponent
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule
    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
