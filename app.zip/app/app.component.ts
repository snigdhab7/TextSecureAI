import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'proj1';
  username:string="John Smith";
  
  childdata:string;
  parentmethod(data){
    this.childdata=data;
  }

}
