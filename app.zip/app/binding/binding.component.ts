import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-binding',
  templateUrl: './binding.component.html',
  styleUrls: ['./binding.component.css']
})
export class BindingComponent implements OnInit {
pageTitle:string="Data Binding in Angular";
btnStatus:boolean=false;
islog:boolean=false;
names:string[]=["raj","rakesh","rahul"];
users:any=[
  {id:1001,name:'raj',age:30},
  {id:1002,name:'rakesh',age:28},
  {id:1003,name:'rahul',age:32}
];
selectedcountry:string;
country=[
{code:'uk',name:'united kingdom'},
{code:'uae',name:'united arab emirates'},
{code:'ind',name:'india'}
];
  constructor() { }

  ngOnInit(): void {
  }
  changeTitle(){
    this.pageTitle="Data Binding";
    
  }
  choice(code){
    this.selectedcountry=code;
  }

}
