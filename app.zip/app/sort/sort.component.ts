import {Component,OnInit} from '@angular/core';
@Component ({

selector: 'app-sort',
template: ` 
<table padding="3" border="3">
<tr>
<th> <input type="button" value="ID" (click)=(idsort())/> </th>
<th> <input type="button" value="Name" (click)=(namesort())/> </th>
<th> <input type="button" value="Salary" (click)=(salarysort())/> </th>
<th> <input type="button" value="Department" /> </th>
<th> <input type="button" value="Joining Date" /> </th>
</tr> 
<tr *ngFor="let e of data"> 
<td> {{e.empId}} </td>
<td> {{e.empName}} </td>
<td> {{e.empSal}} </td>
<td> {{e.empDep}} </td>
<td> {{e.empjoiningdate}} </td>
</tr>
</table>



`,
styles: []


})
export class SortComponent implements OnInit
{
    data= [
        {empId:1001,empName:'Rahul',empSal:9000,empDep:'JAVA',empjoiningdate:'6/12/2014'},
        {empId:1002,empName:'Vikash',empSal:11000,empDep:'ORAAPS',empjoiningdate:'6/12/2017'},
        {empId:1003,empName:'Uma',empSal:12000,empDep:'JAVA',empjoiningdate:'6/12/2010'},
        {empId:1004,empName:'Sachin',empSal:11500,empDep:'ORAAPS',empjoiningdate:'11/12/2017'},
        {empId:1005,empName:'Amol',empSal:7000,empDep:'.NET',empjoiningdate:'1/1/2018'},
        {empId:1006,empName:'Vishal',empSal:17000,empDep:'BI',empjoiningdate:'9/12/2012'},
        {empId:1007,empName:'Rajita',empSal:21000,empDep:'BI',empjoiningdate:'6/7/2014'},
        {empId:1008,empName:'Neelima',empSal:81000,empDep:'TESTING',empjoiningdate:'6/17/2015'},
        {empId:1009,empName:'Daya',empSal:1000,empDep:'TESTING',empjoiningdate:'6/17/2016'} ];



constructor(){}
ngOnInit(){}


    idsort()
  {
    this.data.sort((a,b) =>a.empId < b.empId ? -1 : a.empId>b.empId ? 1 :0);
  }
  namesort()
  {
    this.data.sort((a,b) =>a.empName < b.empName ? -1 :a.empName >b.empName ? 1 : 0);
  }
  salarysort()
  {
    this.data.sort((a,b) =>a.empSal < b.empSal ? -1 :a.empSal >b.empSal ? 1: 0);
  }






}