import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { FormBuilder } from '@angular/forms';

@Component({
    selector: 'app-MDF',
    templateUrl: './MDF.component.html',
    styleUrls: []
})

export class MDFComponent implements OnInit {
    regForm = new FormGroup({
        userName: new FormControl('James'),
        password: new FormControl(),
        confPassword: new FormControl()
    });
    // regForm = this.formBuilder.group({
    //         userName:['',[Validators.required,Validators.minLength(8),Validators.maxLength(15)]],
    //         password:[''],
    //         confPassword:['']
    //     });
   

        constructor(){}
    // constructor(private formBuilder: FormBuilder) { }

    ngOnInit() { }

    Submit() {
        this.regForm.setValue({
            userName: 'Admin',
            confPassword: 'asadmin',
            password: 'asadmin'
        });

        // this.regForm.patchValue({
        //     userName:'RoshniKohli'
        // });
       
    }
}