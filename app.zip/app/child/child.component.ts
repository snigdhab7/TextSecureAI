import { Component, OnInit, Input, Output,EventEmitter } from '@angular/core';


@Component({
  selector: 'app-child',
  template: `<div>
  <h3>this is child component</h3>
  <h4>welcome {{uname}}</h4>
  <button (click)="passdata()">send data to parent</button>
  </div>
  `,
  styles: [`div{
            background:lightgray;
            padding:20px;
            }
`]
})
export class ChildComponent implements OnInit {
    @Input()
    uname:string;
    @Output()
    notify:EventEmitter<string>=new EventEmitter<string>();
    passdata(){
        this.notify.emit("This message is from child component");
    }
   constructor(){}
    ngOnInit(){}
    
}