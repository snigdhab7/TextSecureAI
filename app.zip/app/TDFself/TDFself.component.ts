import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-TDFself',
    templateUrl: `./TDFself.component.html`,
    styles:[`
    input.ng-invalid{border-left:5px solid red;}
    input.ng-valid{border-left:5px solid green;}
    `]
})

export class TDFSelfComponent implements OnInit{
    street:string;
    uname:string="Username123";
    email:string="abc@email.com";
    name:string="Ben";
    constructor(){}
    ngOnInit(){}
    onSubmit(data:any)
    {
        console.log(data);
    }
}